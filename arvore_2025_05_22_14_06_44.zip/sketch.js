function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let jardinero;
let arboles = [];
let temperatura = 25;
let tiempoRestante = 60;
let metaArboles = 20;
let terreno = [];
let juegoGanado = false;
let juegoPerdido = false;
let ultimoArbol = 0;
let intervaloArboles = 1; // segundos entre plantar árboles

function setup() {
  createCanvas(800, 600);
  jardinero = new Jardinero();
  
  // Crear terreno
  for (let x = 0; x < width; x += 20) {
    terreno.push(new Terreno(x, height - 50));
  }
}

function draw() {
  // Fondo que cambia según la temperatura
  if (temperatura < 20) {
    background(100, 150, 255); // Frío - azul
  } else if (temperatura < 30) {
    background(135, 206, 235); // Normal - celeste
  } else {
    background(255, 150, 100); // Caliente - naranja
  }
  
  // Dibujar terreno
  for (let t of terreno) {
    t.mostrar();
  }
  
  // Dibujar árboles
  for (let arbol of arboles) {
    arbol.mostrar();
    arbol.crecer();
  }
  
  // Actualizar y mostrar jardinero
  jardinero.actualizar();
  jardinero.mostrar();
  
  // Mostrar UI
  mostrarUI();
  
  // Actualizar tiempo y temperatura
  if (frameCount % 60 == 0 && !juegoGanado && !juegoPerdido) {
    tiempoRestante--;
    
    // Aumentar temperatura si no se plantan suficientes árboles
    if (arboles.length < metaArboles * (1 - tiempoRestante/60)) {
      temperatura += 0.5;
    } else {
      temperatura -= 0.2; // Enfriar si vamos bien
    }
    
    temperatura = constrain(temperatura, 15, 50);
  }
  
  // Verificar condiciones del juego
  if (arboles.length >= metaArboles && !juegoPerdido) {
    juegoGanado = true;
  } else if (tiempoRestante <= 0 || temperatura >= 50) {
    juegoPerdido = true;
  }
  
  // Mostrar mensajes finales
  if (juegoGanado) {
    fill(0, 200, 0);
    textSize(40);
    textAlign(CENTER);
    text("¡Planeta Salvado!", width/2, height/2);
    textSize(20);
    text("Has plantado suficientes árboles para enfriar el planeta.", width/2, height/2 + 40);
  } else if (juegoPerdido) {
    fill(200, 0, 0);
    textSize(40);
    textAlign(CENTER);
    text("¡Planeta en Peligro!", width/2, height/2);
    textSize(20);
    text("La temperatura aumentó demasiado.", width/2, height/2 + 40);
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    jardinero.mover(-1);
  } else if (keyCode === RIGHT_ARROW) {
    jardinero.mover(1);
  } else if (key === ' ' && !juegoGanado && !juegoPerdido) {
    // Plantar árbol con cooldown
    if (millis() - ultimoArbol > intervaloArboles * 1000) {
      jardinero.plantar();
      ultimoArbol = millis();
    }
  }
}

function mostrarUI() {
  fill(0);
  textSize(16);
  textAlign(LEFT);
  text(`Árboles plantados: ${arboles.length}/${metaArboles}`, 20, 30);
  text(`Temperatura: ${temperatura.toFixed(1)}°C`, 20, 60);
  text(`Tiempo: ${tiempoRestante}s`, 20, 90);
  
  // Barra de temperatura
  noStroke();
  let tempWidth = map(temperatura, 15, 50, 0, 200);
  if (temperatura < 25) {
    fill(100, 100, 255);
  } else if (temperatura < 35) {
    fill(255, 255, 100);
  } else {
    fill(255, 100, 100);
  }
  rect(width - 220, 20, tempWidth, 20);
  noFill();
  stroke(0);
  strokeWeight(1);
  rect(width - 220, 20, 200, 20);
  fill(0);
  textSize(12);
  text("15°C", width - 225, 35);
  text("50°C", width - 10, 35);
}

class Jardinero {
  constructor() {
    this.x = width/2;
    this.y = height - 100;
    this.velX = 0;
    this.ancho = 40;
    this.alto = 60;
    this.plantando = false;
  }
  
  mover(dir) {
    this.velX = dir * 5;
  }
  
  actualizar() {
    this.x += this.velX;
    this.x = constrain(this.x, this.ancho/2, width - this.ancho/2);
    this.velX *= 0.9; // Fricción
  }
  
  mostrar() {
    // Cuerpo
    fill(210, 180, 140);
    rect(this.x - this.ancho/2, this.y - this.alto, this.ancho, this.alto);
    
    // Cabeza
    fill(255, 200, 150);
    ellipse(this.x, this.y - this.alto - 15, 30, 30);
    
    // Sombrero
    fill(100, 70, 40);
    arc(this.x, this.y - this.alto - 20, 40, 20, PI, TWO_PI);
    
    // Herramienta
    if (this.plantando) {
      fill(150, 75, 0);
      rect(this.x + 10, this.y - 30, 5, 30);
      fill(200);
      triangle(this.x + 15, this.y - 30, this.x + 25, this.y - 40, this.x + 15, this.y - 40);
    }
    
    // Resetear estado de plantación
    if (this.plantando && millis() - ultimoArbol > 500) {
      this.plantando = false;
    }
  }
  
  plantar() {
    this.plantando = true;
    arboles.push(new Arbol(this.x, height - 50));
  }
}

class Arbol {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamano = 5;
    this.tamanoMax = random(30, 50);
    this.crecimiento = random(0.05, 0.1);
  }
  
  crecer() {
    if (this.tamano < this.tamanoMax) {
      this.tamano += this.crecimiento;
    }
  }
  
  mostrar() {
    // Tronco
    fill(150, 75, 0);
    rect(this.x - 3, this.y - this.tamano, 6, this.tamano);
    
    // Copa
    fill(34, 139, 34);
    noStroke();
    ellipse(this.x, this.y - this.tamano - 10, this.tamano + 10, this.tamano + 10);
    stroke(0);
  }
}

class Terreno {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.ancho = 20;
    this.alto = 50;
    this.verde = random(100, 200);
  }
  
  mostrar() {
    fill(50, this.verde, 50);
    rect(this.x, this.y, this.ancho, this.alto);
  }
}